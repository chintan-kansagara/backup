import { NgModule } from '@angular/core';

import { FeatherModule } from 'app/main/ui/icons/feather/feather.module';

@NgModule({
  declarations: [],
  imports: [FeatherModule]
})
export class IconsModule {}
