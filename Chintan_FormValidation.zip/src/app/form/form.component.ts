import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  form: any;
  isSubmitted = false;
  constructor() { }

  ngOnInit(): void {
    this.form = new FormGroup({
      firstname: new FormControl('', Validators.required),
      lastname: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      number: new FormControl('', [
        Validators.required,
        Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
      ]),
      courses: new FormControl('', [Validators.required]),
      gender: new FormControl('male', Validators.required),
      checkbox: new FormControl('', Validators.required)
    });
  }
  get firstname() {
    return this.form.get('firstname');
  }
  get lastname() {
    return this.form.get('lastname');
  }
  get email() {
    return this.form.get('email')
  }
  get number() {
    return this.form.get('number');
  }
  get courses() {
    return this.form.get('courses');
  }
  get checkbox() {
    return this.form.get('checkbox')
  }

  print() {
    this.isSubmitted = true;
    if (this.form.valid) {
      console.log(this.form.value);
      this.isSubmitted = false;
    }
  }

}
