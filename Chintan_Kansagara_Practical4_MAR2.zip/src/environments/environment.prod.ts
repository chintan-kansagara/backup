export const environment = {
   firebase : {

    apiKey: "AIzaSyCdmKZwk4zvMjWeqOaSqI0FfoZcMhUgZII",
  
    authDomain: "student-management-syste-575a1.firebaseapp.com",
  
    projectId: "student-management-syste-575a1",
  
    storageBucket: "student-management-syste-575a1.appspot.com",
  
    messagingSenderId: "215899305627",
  
    appId: "1:215899305627:web:c6f423f6b2c41accf3783e"
  
  },
  production: true,
  
};
