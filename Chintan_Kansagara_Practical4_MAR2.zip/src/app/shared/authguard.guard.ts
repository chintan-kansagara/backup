import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardGuard implements CanActivate {
  constructor(private data: DataService, private router: Router) {
  }
  canActivate() {
    if (this.data.isLoggedIn()) {
      return true;
    } else {
      // this.router.navigate(['login']);
      return false;
    }
  }
}
