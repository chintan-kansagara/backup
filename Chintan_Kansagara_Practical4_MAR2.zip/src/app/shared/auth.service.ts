import { ToastrService } from 'ngx-toastr';
import { Student } from './../component/model/student';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth'
import { Router } from '@angular/router';
import { GoogleAuthProvider } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private fireauth: AngularFireAuth, private router: Router, private toastr: ToastrService) { }
  //Login 
  login(email: any, password: any) {
    this.fireauth.signInWithEmailAndPassword(email, password).then((res) => {
      localStorage.setItem('token', 'true');
      console.log(res.user)
      this.toastr.success("Login Succesfully");
      if (res.user?.emailVerified == true) {
        this.router.navigate(['dashboard'])
      } else {
        this.router.navigate(['verify-email']);
      }

    }, err => {
      alert(err.message);
      this.router.navigate(['/login']);
    })
  }

  //Logout
  logout() {
    this.fireauth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['/login'])
    }, err => {
      alert(err.message);
    })
  }

  //Registration
  register(email: any, password: any, first_name: any, last_name: any, age: any, mobile: any) {
    this.fireauth.createUserWithEmailAndPassword(email, password).then((res) => {
      alert('Registration is Successfull')
      this.router.navigate(['/login']);
      this.sendEmailForVerification(res.user);
    }, err => {
      alert(err.message)
      this.router.navigate(['/register'])
    })
  }

  //Email for Verification
  sendEmailForVerification(user: any) {
    user.sendEmailVerification().then((res: any) => {
      this.router.navigate(['verify-email']);
    }, (err: any) => {
      alert('Something went wrong. Not able to send mail to your registered email.')
    })
  }

  //Sign in Google
  googleSignIn() {
    return this.fireauth.signInWithPopup(new GoogleAuthProvider).then((res) => {
      this.router.navigate(['/dashboard']);
      localStorage.setItem('token', JSON.stringify(res.user?.uid))
      this.toastr.success("Login Successfull")
    }, err => {
      alert(err.message);
    })
  }

  //Forgot Password
  forgotPassword(email: any) {
    this.fireauth.sendPasswordResetEmail(email).then(() => {
      this.router.navigate(['/verify-email']);
    }, err => {
      console.log(err);
    })
  }
}
