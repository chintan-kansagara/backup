import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { AppModule } from '../app.module';
import { DashboardComponent } from '../component/dashboard/dashboard.component';
import { Student } from '../component/model/student';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private firestore: AngularFirestore) { }

  //add student
  addStudent(student: Student) {
    student.id = this.firestore.createId();
    return this.firestore.collection('/students').add(student);
  }

  //check if login or notfirestore
  isLoggedIn() {
    return localStorage.getItem('token')
  }

  //get all students
  getAllStudents() {
    return this.firestore.collection('/students').snapshotChanges();
  }

  //delete student
  deleteStudent(student: Student) {
    return this.firestore.doc('/students/' + student.id).delete();
  }

  //update student
  updateStudent(student: Student) {
    console.log("student.id", student.id);
    return this.firestore.doc('/students/' + student.id).update(student);
  }
}
