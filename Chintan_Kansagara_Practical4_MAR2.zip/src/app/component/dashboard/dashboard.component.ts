import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/shared/data.service';
import { Student } from '../model/student';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  displayedColumns: string[] = ['first_name', 'last_name', 'email', 'mobile', 'age', 'action'];

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  isHidden = false;
  studentsList: Student[] = [];
  isSubmitted = false;
  users: any = [];
  editedUser: any;
  hide: any
  isEdit = false;
  form!: FormGroup;
  dataSource = new MatTableDataSource(this.studentsList);
  StudentTitle: string = 'Student List'
  DataObj: Student = {
    id: '',
    first_name: '',
    last_name: '',
    email: '',
    mobile: '',
    age: ''
  };
  firstname = 'Chintan Kansagara';
  lastname: any;
  value: any;
  constructor(private data: DataService, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      first_name: new FormControl('', Validators.required),
      last_name: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      mobile: new FormControl('', [
        Validators.required,
        Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
      ]),
      age: new FormControl('', Validators.required),
    });
    this.getAllStudents();
  }

  get first_name() {
    return this.form.get('first_name');
  }
  get last_name() {
    return this.form.get('last_name');
  }
  get email() {
    return this.form.get('email')
  }
  get mobile() {
    return this.form.get('mobile');
  }
  get age() {
    return this.form.get('age');
  }

  getAllStudents() {
    this.isSubmitted = true;

    this.data.getAllStudents().subscribe(
      (res) => {
        this.studentsList = res.map((e: any) => {
          const data = e.payload.doc.data();
          data.id = e.payload.doc.id;
          console.log(data)
          return data;

        });
        this.dataSource.data = this.studentsList;
        this.dataSource.paginator = this.paginator;
      },
      (err) => {
        alert('Error while fetching student data');
      }
    );
    this.isSubmitted = false;
  }

  display() {
    this.isHidden = true;
  }

  cancel() {
    this.isHidden = false;
    this.form.reset();
    this.isEdit = false;
  }
 
  addStudent() {
    this.isSubmitted = true;
    this.DataObj.id = '';
    this.DataObj.first_name = this.form.value.first_name;
    this.DataObj.last_name = this.form.value.last_name;
    this.DataObj.email = this.form.value.email;
    this.DataObj.mobile = this.form.value.mobile;
    this.DataObj.age = this.form.value.age;
    
    if (this.form.valid) {
      this.data.addStudent(this.DataObj);
      this.toastr.success("Data Added Succesfully");
      this.form.reset();
      this.isHidden = false;      this.toastr.success("Data Added Succesfully");

    }
  }
  //search
  public doFilter(value: any) {
    this.dataSource.filter = value.value.trim().toLowerCase();
  }

  deleteStudent(student: Student) {
    if (
      window.confirm(
        'Are you sure you want to delete ' +
        student.first_name +
        ' ' +
        student.last_name +
        ' ?'
      )
    ) {
      this.data.deleteStudent(student);
      this.toastr.success("Data Deleted Succesfully");
    }
  }

  fillDetails(student: any) {
    this.isEdit = true;
    this.isHidden = true;
    this.DataObj.id = student.id;
    this.form.controls['first_name'].setValue(student.first_name);
    this.form.controls['last_name'].setValue(student.last_name);
    this.form.controls['email'].setValue(student.email);
    this.form.controls['mobile'].setValue(student.mobile);
    this.form.controls['age'].setValue(student.age);
  }

  updateStudent() {
    this.DataObj.id = this.DataObj.id;
    this.DataObj.first_name = this.form.value.first_name;
    this.DataObj.last_name = this.form.value.last_name;
    this.DataObj.email = this.form.value.email;
    this.DataObj.mobile = this.form.value.mobile;
    this.DataObj.age = this.form.value.age;
    this.data.updateStudent(this.DataObj);
    this.toastr.success("Data Updated Succesfully");
    this.cancel();
  }

  logout() {
    localStorage.removeItem('token')
    this.router.navigate(['/login'])
  }
}
