import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-email',
  templateUrl: './verify-email.component.html',
  styleUrls: ['./verify-email.component.css']
})
export class VerifyEmailComponent implements OnInit {

  constructor(private Router: Router) { }

  ngOnInit(): void {
  }
  backToLogin() {
    this.Router.navigate(['login'])
  }
}
