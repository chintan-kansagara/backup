import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/auth.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  form!: FormGroup;
  hide: any;
  isSubmitted: any;
  constructor(private auth: AuthService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      email: new FormControl('', [
        Validators.required,
      ]),
      password: new FormControl('', [
        Validators.required,
      ]),
    });
  }

  get email() {
    return this.form.get('email');
  }
  get password() {
    return this.form.get('password');
  }

  login() {

    if (this.form.valid) {
      let data = this.form.value;
      this.auth.login(data.email, data.password);
      
      this.form.reset();
    } else {
      alert("Username or Password is Invalid");
    }
  }

  signInWithGoogle() {
    this.auth.googleSignIn();
  }
}
