import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from 'src/app/shared/auth.service';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  form!: FormGroup;
  isSubmitted = false;
  hide: any;
  constructor(private auth: AuthService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      first_name: new FormControl('', Validators.required),
      last_name: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      age: new FormControl('', [
        Validators.required,
      ]),
      password: new FormControl('', Validators.required),
      mobile: new FormControl('', [
        Validators.required,
        Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
      ]),
    });
  }

  get first_name() {
    return this.form.get('first_name');
  }
  get last_name() {
    return this.form.get('last_name');
  }
  get email() {
    return this.form.get('email')
  }
  get mobile() {
    return this.form.get('mobile');
  }
  get password() {
    return this.form.get('password');
  }
  get age() {
    return this.form.get('age');
  }

  register() {
    this.isSubmitted = true;
    let data = this.form.value;
    if (this.form.valid) {
      this.auth.register(data.email, data.password, data.first_name, data.last_name, data.age, data.mobile);
      this.toastr.success("Registered Successfully")
      this.form.reset();
    }
    this.isSubmitted = false;
  }
}
