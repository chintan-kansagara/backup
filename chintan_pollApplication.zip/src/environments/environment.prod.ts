export const environment = {
  firebase: {
    projectId: 'poll-e1da3',
    appId: '1:563441047459:web:611754ddf718314b212c16',
    storageBucket: 'poll-e1da3.appspot.com',
    apiKey: 'AIzaSyCZKF4kUJaDMo5GaSyzpKGEYZo88LGYdOg',
    authDomain: 'poll-e1da3.firebaseapp.com',
    messagingSenderId: '563441047459',
  },
  production: true
};
