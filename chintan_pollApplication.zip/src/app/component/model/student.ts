export interface agenda {
    id:string,
    agenda:string,
}
