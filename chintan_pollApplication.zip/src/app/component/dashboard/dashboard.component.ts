import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { agenda } from '../model/student';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  form!: FormGroup;
  hide: any;
  isSubmitted: any;
  DataObj: agenda = {
    id: '',
    agenda: ''
  };
  constructor(private auth: AuthService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      agenda: new FormControl('', Validators.required),
      id: new FormControl('', Validators.required)
    });
  }

  get agenda() {
    return this.form.get('agenda');
  }
  get id() {
    return this.form.get('id');
  }

  addAgenda(){
    this.isSubmitted = true;
    this.DataObj.id = this.form.value.id;
    this.DataObj.agenda = this.form.value.agenda;
        
    if (this.form.valid) {
      this.auth.addAgenda(this.DataObj);
      this.form.reset();
    }
  }
}
