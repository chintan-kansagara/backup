import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/compat/auth'
import { ToastrService } from 'ngx-toastr';
import { GoogleAuthProvider } from '@angular/fire/auth';
import { agenda } from '../component/model/student';
import { AngularFirestore } from '@angular/fire/compat/firestore';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private fireauth: AngularFireAuth, private router: Router, private toastr: ToastrService,private firestore: AngularFirestore) { }

  login(email: any, password: any) {
    this.fireauth.signInWithEmailAndPassword(email, password).then((res) => {
      localStorage.setItem('token', 'true');
      console.log(res.user)
      this.toastr.success("Login Succesfully");
      if (res.user?.emailVerified == true) {
        this.router.navigate(['dashboard'])
      } else {
        this.router.navigate(['verify-email']);
      }

    }, err => {
      alert(err.message);
      this.router.navigate(['/login']);
    })
  }

  //Logout
  logout() {
    this.fireauth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['/login'])
    }, err => {
      alert(err.message);
    })
  }

  //Registration
  register(email: any, password: any, first_name: any, last_name: any, age: any, mobile: any) {
    this.fireauth.createUserWithEmailAndPassword(email, password).then((res) => {
      alert('Registration is Successfull')
      this.router.navigate(['/login']);
      this.sendEmailForVerification(res.user);
    }, err => {
      alert(err.message)
      this.router.navigate(['/register'])
    })
  }

  //Email for Verification
  sendEmailForVerification(user: any) {
    user.sendEmailVerification().then((res: any) => {
      this.router.navigate(['verify-email']);
    }, (err: any) => {
      alert('Something went wrong. Not able to send mail to your registered email.')
    })
  }

  //Sign in Google
  googleSignIn() {
    return this.fireauth.signInWithPopup(new GoogleAuthProvider).then((res) => {
      this.router.navigate(['/dashboard']);
      localStorage.setItem('token', JSON.stringify(res.user?.uid))
      this.toastr.success("Login Successfull")
    }, err => {
      alert(err.message);
    })
  }
  addAgenda(agenda: agenda) {
    //agenda.id = this.firestore.createId();
    return this.firestore.collection('/agenda').add(agenda);
  }

  getAgenda() {
    return this.firestore.collection('/agenda').snapshotChanges();
  }

  //Forgot Password
  forgotPassword(email: any) {
    this.fireauth.sendPasswordResetEmail(email).then(() => {
      this.router.navigate(['/verify-email']);
    }, err => {
      console.log(err);
    })
  }
}
