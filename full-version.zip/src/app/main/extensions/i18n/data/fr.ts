export const locale = {
  lang: 'fr',
  data: {
    CARD: {
      TITLE: 'Titre de la',
      TEXT:
        "Une structure de code propre, commentée et bien formatée vous permet de démarrer rapidement votre projet en un rien de temps. Le modèle offre une grande personnalisation et vous permet de vous l'approprier avec l'utilisation de différents éléments modulaires et la personnalisation des fichiers SASS. Grande combinaison de fonctionnalités, de composants et d'un design moderne"
    }
  }
};
