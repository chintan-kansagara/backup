export const locale = {
  lang: 'pt',
  data: {
    CARD: {
      TITLE: 'Título',
      TEXT:
        'A estrutura de código limpa, comentada e bem formatada permite iniciar rapidamente seu projeto rapidamente. O modelo fornece ótima personalização e permite que você faça o seu próprio com o uso de diferentes elementos modulares e a personalização dos arquivos SASS. Ótima combinação de recursos, componentes e design moderno'
    }
  }
};
