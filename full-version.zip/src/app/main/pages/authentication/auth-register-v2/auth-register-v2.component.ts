import { ToastrService } from 'ngx-toastr';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';

import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

import { CoreConfigService } from '@core/services/config.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserService } from 'app/auth/service';

@Component({
  selector: 'app-auth-register-v2',
  templateUrl: './auth-register-v2.component.html',
  styleUrls: ['./auth-register-v2.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AuthRegisterV2Component implements OnInit {
  // Public
  public coreConfig: any;
  public passwordTextType: boolean;
  public registerForm: UntypedFormGroup;
  public submitted = false;

  // Private
  private _unsubscribeAll: Subject<any>;

  /**
   * Constructor
   *
   * @param {CoreConfigService} _coreConfigService
   * @param {FormBuilder} _formBuilder
   */
  constructor(private _coreConfigService: CoreConfigService, private _formBuilder: UntypedFormBuilder,private router: Router, private http: HttpClient,private usersService: UserService,private toastr: ToastrService) {
    this._unsubscribeAll = new Subject();

    // Configure the layout
    this._coreConfigService.config = {
      layout: {
        navbar: {
          hidden: true
        },
        menu: {
          hidden: true
        },
        footer: {
          hidden: true
        },
        customizer: false,
        enableLocalStorage: false
      }
    };
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.registerForm.controls;
  }

  /**
   * Toggle password
   */
  togglePasswordTextType() {
    this.passwordTextType = !this.passwordTextType;
  }



  // Lifecycle Hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   * 
   */
  expression="^((\\+91-?)|0)?[0-9]{10}$"
  ngOnInit(): void {
    this.registerForm = this._formBuilder.group({
      username: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      phoneNumber: ['', [Validators.required,Validators.pattern(this.expression)]]
    });

    // Subscribe to config changes
    this._coreConfigService.config.pipe(takeUntil(this._unsubscribeAll)).subscribe(config => {
      this.coreConfig = config;
    });
  }

  get username() {
    return this.registerForm.get('username');
  }
  get email() {
    return this.registerForm.get('email');
  }
  get password() {
    return this.registerForm.get('password')
  }
  get confirmPassword() {
    return this.registerForm.get('confirmPassword');
  }
  get phoneNumber() {
    return this.registerForm.get('phoneNumber');
  }
  
    /**
   * On Submit
   */
    onSubmit() {
      this.submitted = true;
      
      if (this.registerForm.valid) {
        let formData = new FormData();
        formData.append('name', this.registerForm.get('username').value);
        formData.append('email', this.registerForm.get('email').value);
        formData.append('password', this.registerForm.get('password').value);
        formData.append('confirm_password', this.registerForm.get('confirmPassword').value);
        formData.append('phone_no', this.registerForm.get('phoneNumber').value);
    
         
          this.usersService.registerUser(formData).subscribe((res: any) => {
            this.toastr.success("Successfully Registered");
            console.log("Successfully Registered")
            this.router.navigate(['/pages/authentication/login-v2']);
          }, error => {
            console.log(error)
            this.toastr.error(error);
            this.router.navigate(['/pages/authentication/register-v2']);
          })
      }
      // stop here if form is invalid
      if (this.registerForm.invalid) {
      }
    }


  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }
}
