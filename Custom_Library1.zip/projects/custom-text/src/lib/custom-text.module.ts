import { NgModule } from '@angular/core';
import { CustomTextComponent } from './custom-text.component';



@NgModule({
  declarations: [
    CustomTextComponent
  ],
  imports: [
  ],
  exports: [
    CustomTextComponent
  ]
})
export class CustomTextModule { }
