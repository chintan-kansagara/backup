import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-custom-text',
  template: `
    <p>
      custom-text works!
    </p>
  `,
  styles: [
  ]
})
export class CustomTextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
