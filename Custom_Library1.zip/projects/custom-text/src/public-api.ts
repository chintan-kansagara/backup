/*
 * Public API Surface of custom-text
 */

export * from './lib/custom-text.service';
export * from './lib/custom-text.component';
export * from './lib/custom-text.module';
