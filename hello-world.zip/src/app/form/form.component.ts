import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators } from '@angular/forms';
 import { Router } from '@angular/router';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  isSubmitted = false;
  ngOnInit(): void {
  }

  form = new FormGroup({
    firstname: new FormControl('', Validators.required),
    lastname: new FormControl('', Validators.required),
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    number: new FormControl('',[
      Validators.required,
      Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
    ]),
    courses: new FormControl('',[Validators.required]),
    gender: new FormControl('male')
  });
  

  get firstname(){
    return this.form.get('firstname');
  }
  get lastname(){
    return this.form.get('lastname');
  }
  get email(){
    return this.form.get('email')
  }
  get number(){
    return this.form.get('number');
  }
  get courses(){
    return this.form.get('courses');
  }
  



  register(){    
    this.isSubmitted = true;
    if(this.form.valid) {
      let nameArr = [];
      let detail = this.form.value;
      nameArr.push(detail);
      localStorage.setItem('detail',JSON.stringify(nameArr));
      this.form.reset();
      this.isSubmitted = false;
    }
    
    // console.log(this.form.value);
    //   this.firstname?.setErrors({
    //     invalidLogin: true
    //   })
  }

}

