import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
  detail: any;
  constructor() { }

  ngOnInit(): void {
    this.detail = [
      {
        FirstName: 'Chintan',
        LastName: 'Kansagara',
        Age: '21',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'tej',
        LastName: 'Kansagara',
        Age: '22',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'kirtan',
        LastName: 'Modi',
        Age: '23',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'divyanshu',
        LastName: 'Kansagara',
        Age: '24',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'dhwanil',
        LastName: 'Kansagara',
        Age: '25',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'shyam',
        LastName: 'Kansagara',
        Age: '26',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'kenil',
        LastName: 'Kansagara',
        Age: '27',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'nayan',
        LastName: 'Kansagara',
        Age: '28',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'devang',
        LastName: 'Kansagara',
        Age: '29',
        BirthDate: '2001/06/16'
      },
      {
        FirstName: 'om',
        LastName: 'Kansagara',
        Age: '30',
        BirthDate: '2001/06/16'
      }
    ]
  }

}
