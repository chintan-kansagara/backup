import { Injectable } from '@angular/core';
import { AngularFireStorage} from '@angular/fire/compat/storage';
import { AngularFirestore} from '@angular/fire/compat/firestore'
import { FileMetaData } from '../model/file-meta-data';

@Injectable({
  providedIn: 'root'
})
export class FileService {

  constructor(private firestore: AngularFirestore, private firestorage: AngularFireStorage) { }

  //save meta data of file to firestore
  saveMetaDataOfFile(fileObj: FileMetaData){
    const fileMeta = {
      id : '',
      name : fileObj.name,
      url : fileObj.url,
      size : fileObj.size
    }
    fileMeta.id = this.firestore.createId();

    this.firestore.collection('/Upload').add(fileMeta);
  }

  //display all files
  getAllFiles(){
    this.firestore.collection('/Uploads').snapshotChanges();
  }

  //delete file
  deleteFiles(fileMeta : FileMetaData){
    this.firestore.collection('/Uploads').doc(fileMeta.id).delete();
    this.firestorage.ref('/Uploads/'+fileMeta.name).delete();
  }
}
