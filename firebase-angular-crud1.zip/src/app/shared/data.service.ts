import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Student } from '../model/student';
import { idToken } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root'
})

export class DataService {

  constructor(private firestore: AngularFirestore) { }

  //add student
  addStudent(student: Student) {
    student.id = this.firestore.createId();
    return this.firestore.collection('/students').add(student);
  }

  //check if login or not
  isLoggedIn() {
    return localStorage.getItem('token')
  }

  //get all students
  getAllStudents() {
    return this.firestore.collection('/students').snapshotChanges();
  }

  //delete student
  deleteStudent(student: Student) {
    return this.firestore.doc('/students/' + student.id).delete();
  }

  //update student
  updateStudent(student: Student) {
    console.log("student.id", student.id);
      return this.firestore.doc('/students/' + student.id).update(student);
  } 
}
