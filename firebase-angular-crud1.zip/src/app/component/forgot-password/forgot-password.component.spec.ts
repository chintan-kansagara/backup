import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotPasswordComponent } from './forgot-password.component';
import { AuthService } from '../../shared/auth.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


describe('ForgotPasswordComponent', () => {
  let component: ForgotPasswordComponent;
  let fixture: ComponentFixture<ForgotPasswordComponent>;

  beforeEach(async () => {
    let MockAuthService = TestBed.get(AuthService)
    await TestBed.configureTestingModule({
      declarations: [ ForgotPasswordComponent ],
      imports: [FormsModule, ReactiveFormsModule],
      providers: [{ provide: AuthService, useClass: true }],
      
    })
    .compileComponents();
    fixture = TestBed.createComponent(ForgotPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
