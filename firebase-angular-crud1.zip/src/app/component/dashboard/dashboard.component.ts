import { Student } from './../../model/student';
import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/shared/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  StudentTitle: string = 'Student List'
  studentsList: Student[] = [];
  studentObj: Student = {
    id: '',
    first_name: '',
    last_name: '',
    email: '',
    mobile: '',
  };
  id: string = '';
  first_name: string = '';
  last_name: string = '';
  email: string = '';
  mobile: string = '';


  constructor(private data: DataService,private router: Router) {}

  ngOnInit(): void {
    this.getAllStudents();
  }

  // register(){
  //   this.auth.logout();
  // }

  getAllStudents() {
    this.data.getAllStudents().subscribe(
      (res) => {
        this.studentsList = res.map((e: any) => {
          const data = e.payload.doc.data();
          data.id = e.payload.doc.id;
          return data;
        });
      },
      (err) => {
        alert('Error while fetching student data');
      }
    );
  }

  resetForm() {
    this.id = '';
    this.first_name = '';
    this.last_name = '';
    this.email = '';
    this.mobile = '';
  }

  addStudent() {
    if (
      this.first_name == '' ||
      this.last_name == '' ||
      this.email == '' ||
      this.mobile == ''
    ) {
      alert('Fill all the values');
    }
    else{
    this.studentObj.id = '';
    this.studentObj.email = this.email;
    this.studentObj.first_name = this.first_name;
    this.studentObj.last_name = this.last_name;
    this.studentObj.mobile = this.mobile;

    this.data.addStudent(this.studentObj);
    this.resetForm();
    }
  }

  

  deleteStudent(student: Student) {
    if (
      window.confirm(
        'Are you sure you want to delete ' +
          student.first_name +
          ' ' +
          student.last_name +
          ' ?'
      )
    ) {
      this.data.deleteStudent(student);
    }
  }

  onEdit(student:any){
    this.id = student.id;
    this.first_name = student.first_name;
    this.last_name = student.last_name;
    this.email = student.email;
    this.mobile = student.mobile;
  }

  updateStudent() {
    this.studentObj.id = this.id;
    this.studentObj.email = this.email;
    this.studentObj.first_name = this.first_name;
    this.studentObj.last_name = this.last_name;
    this.studentObj.mobile = this.mobile;
    //console.log("this.studentObj", this.studentObj)
    this.data.updateStudent(this.studentObj);
  }

  logout(){
    localStorage.removeItem('token')
    this.router.navigate(['/login'])
  }
}
