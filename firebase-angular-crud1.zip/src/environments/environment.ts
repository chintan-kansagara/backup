// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  // firebase: {
  //   projectId: 'student-management-syste-20b22',
  //   appId: '1:288769997520:web:ebfa0ed26bd2c82f65fcd5',
  //   storageBucket: 'student-management-syste-20b22.appspot.com',
  //   apiKey: 'AIzaSyAkNvwTbomymqKSj7sbIul7bfYHOE7Qx7k',
  //   authDomain: 'student-management-syste-20b22.firebaseapp.com',
  //   messagingSenderId: '288769997520',
  // },
  firebase : {

    apiKey: "AIzaSyCdmKZwk4zvMjWeqOaSqI0FfoZcMhUgZII",
  
    authDomain: "student-management-syste-575a1.firebaseapp.com",
  
    projectId: "student-management-syste-575a1",
  
    storageBucket: "student-management-syste-575a1.appspot.com",
  
    messagingSenderId: "215899305627",
  
    appId: "1:215899305627:web:c6f423f6b2c41accf3783e"
  
  },
  production: false
  // firebaseConfig: {
  //   apiKey: 'AIzaSyAkNvwTbomymqKSj7sbIul7bfYHOE7Qx7k',
  //   authDomain: 'student-management-syste-20b22.firebaseapp.com',
  //   projectId: 'student-management-syste-20b22',
  //   storageBucket: 'student-management-syste-20b22.appspot.com',
  //   messagingSenderId: '288769997520',
  //   appId: '1:288769997520:web:ebfa0ed26bd2c82f65fcd5',
  // },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
