import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Chintan_Pipe';
 
    constructor() { }
  
    ngOnInit(): void {
    }
  
  
    data = [{
  
      title: "Details",
      Firstname: "chintan",
      Lastname: "kansagara",
      Age: 22,
      Date: '2023/3/7',
      Month: 3
  
    },
    {
  
      title: "Details",
      Firstname: "tej",
      Lastname: "modi",
      Age: 22,
      Date: '2023/2/7',
      Month: 2
    },
    {
  
      title: "Details",
      Firstname: "hasti",
      Lastname: "Jasanii",
      Age: 20,
      Date: '2023/2/7',
      Month: 2
    },
    {
  
      title: "Details",
      Firstname: "Tulsi",
      Lastname: "Patel",
      Age: 19,
      Date: '2023/2/7',
      Month: 2
    },
    {
  
      title: "Details",
      Firstname: "Megha",
      Lastname: "Kansagara",
      Age: 23,
      Date: '2023/2/7',
      Month: 2
    },
    {
      title: "Details",
      Firstname: "Dhwanil",
      Lastname: "Dattani",
      Age: 19,
      Date: '2022/3/2',
      Month: 3
    },
    {
      title: "Details",
      Firstname: "",
      Lastname: "",
      Age: 15,
      Date: '2021/4/1',
      Month: 4
    },
    ]
  }

