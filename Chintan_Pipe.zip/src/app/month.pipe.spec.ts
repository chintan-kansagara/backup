import { MonthPipe } from './month.pipe';

describe('MonthPipe', () => {
  it('create an instance', () => {
    const pipe = new MonthPipe();
    expect(pipe).toBeTruthy();
  });
});
