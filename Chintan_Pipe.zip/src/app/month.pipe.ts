import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'month'
})
export class MonthPipe implements PipeTransform {

  transform(value: any): any {
    if(value === undefined || value === null){
      return '';
    }
    const months = [
      'January','February','March','April','May','June','July','August','Sepetember','October','November','December'
    ];
    const monthIndex = parseInt(value, 10) - 1;
    return months[monthIndex];
  }
}
