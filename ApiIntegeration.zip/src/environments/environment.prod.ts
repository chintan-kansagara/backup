export const environment = {
  production: true,
  apiUrl:'https://phplaravel-886096-3128455.cloudwaysapps.com/api'
};
