import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { environment } from 'src/environments/environment'

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  url:string=environment.apiUrl

  login(data: any) {
    return this.http.post<any>(this.url+"/v1/login", data)
  }

  registerUser(data:any){
    return this.http.post<any>(this.url+'/v1/register',data)
  }

  isLoggedIn() {
    return localStorage.getItem('token')
  }

  getData() {
    return this.http.get(this.url+"/v1/userList")
      .pipe(map((res: any) => {
        return res;
      }));
  }

  getPlaylist(pageIndex) {
    return this.http.get(this.url+"/v1/playlist?page=" + pageIndex)
  }

  addPlaylist(data: any) {
    return this.http.post(this.url+"/v1/storeplaylist", data);
  }

  deletePlaylist(id: any) {
    return this.http.delete(this.url+`/v1/deleteplaylist/${id}`);
  }

  getList(id: any) {
    return this.http.get(this.url+`/v1/editplaylist/${id}`);
  }

  updatePlaylist(id: any, data: any) {
    return this.http.post(this.url+`/v1/updateplaylist/${id}`, data.value);
  }
}
