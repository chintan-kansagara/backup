import { UserService } from '../shared/user.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Data } from './data';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  data: any;
  DataObj: Data = new Data();
  form!: FormGroup;

  page: number = 1;
  count: number = 0;
  tableSize: number = 10;
  tableSizes: any = [5, 10, 20, 50];

  playlist: any;
  isAdded = false;
    
  post: any = {
    title: '',
    image_path: ''
  }

  constructor(private router: Router, private toastr: ToastrService, private userservice: UserService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      title: new FormControl('', [Validators.required]),
      image_path: new FormControl('', [Validators.required]),
    });
    this.fetchData(this.page);
  }

  cancel() {
    this.form.reset();
  }

  logout() {
    localStorage.getItem("token");
    console.log('token')
    localStorage.removeItem("token");
    this.toastr.warning("Logged Out");
    this.router.navigate(['login']);
  }

  fetchData(pageIndex) {
    this.userservice.getPlaylist(pageIndex).subscribe((playlist: any) => {
      this.data = playlist.data.data;
      this.count = playlist.data.total;
      this.page = pageIndex;
      console.log(playlist);
      console.log(this.count);
    })
  }

  add() {
    const data = {
      title: this.form.value.title,
      image_path: this.form.value.image_path
    };
    this.userservice.addPlaylist(data).subscribe((res: any) => {
      console.log(res);
      this.isAdded = true;
      this.toastr.success("Data Added Successfully");
      this.fetchData(this.page);
      this.form.reset();
    });
  }

  edit(row: any) {
    this.DataObj.id = row.id;
    this.form.controls['title'].setValue(row.title);
    this.form.controls['image_path'].setValue(row.image_path);
  }

  delete(row: any) {
    if (window.confirm('Are you sure you want to delete?')) {
      this.userservice.deletePlaylist(row.id)
        .subscribe(res => {
          this.toastr.warning('Data deleted successfully.');
          this.fetchData(this.page);
        })
    }
  }

  update() {
    console.log(this.DataObj)
    this.userservice.updatePlaylist(this.DataObj.id, this.form)
      .subscribe(res => {
        this.toastr.success('Data updated successfully.');
        this.fetchData(this.page)
      })
    this.form.reset();
  }

  onTableDataChange(event: any) {
    this.page = event;
    this.fetchData(this.page);
  }
  onTableSizeChange(event: any): void {
    this.page = this.count;
    this.fetchData(this.page);
  }
}