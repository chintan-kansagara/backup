export class Data{
    id: number = 0;
    title: string ='';
    image_path: string ='';
}