import { JsonPipe } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog1',
  templateUrl: './dialog1.component.html',
  styleUrls: ['./dialog1.component.css']
})
export class Dialog1Component implements OnInit {
  userData:any;
  //@Input() childPosts:any[]=[];
  constructor() { }

  ngOnInit(): void {
    this.userData = JSON.parse(localStorage.getItem("post")!);
    console.log("dvcsdjhcbs",localStorage.getItem("post"))
    console.warn(this.userData)
  }

  clearAll(){
    this.userData = [];
    localStorage.removeItem("post");
    localStorage.removeItem("count");
    window.location.reload();
  }

}
