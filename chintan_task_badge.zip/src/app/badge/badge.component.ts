import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {MatDialog, MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import { Dialog1Component } from './dialog1/dialog1.component';

@Component({
  selector: 'badge',
  templateUrl: './badge.component.html',
  styleUrls: ['./badge.component.css']
})
export class BadgeComponent implements OnInit {

  form!: FormGroup;
  hide: any;
  isSubmitted: any;
  badgeCount!:any;
  count:number = 1;
  userPosts:any[]=[]
  post: any;
  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      name: new FormControl('', [
        Validators.required,
      ]),
      designation: new FormControl('', [
        Validators.required,
      ]),
    });
    this.badgeCount=parseInt(localStorage.getItem("count")!)||0
  }

  get name() {
    return this.form.get('name');
  }
  get designation() {
    return this.form.get('designation');
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(Dialog1Component, {
    });
  }

  submit(){
    if(this.form.valid){
      let post = {
        name : this.form.value.name,
        designation:this.form.value.designation
      }
      this.userPosts.push(post);
      console.log(this.userPosts)
      this.badgeCount++;
      localStorage.setItem('count',this.badgeCount)
      let x : any = this.userPosts
      localStorage.setItem("post",JSON.stringify(x))     
      this.form.reset();
    }
  }
}
