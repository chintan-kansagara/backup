export class StudentModel{
    id:number=0;
    firstname:string="";
    lastname:string="";
    email:string="";
    number:string="";
    courses:string="";
    gender:string="";
}