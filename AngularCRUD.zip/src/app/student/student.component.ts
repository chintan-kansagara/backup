import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from '../shared/api.service';
import { StudentModel } from './student.model';

@Component({
  selector: 'student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  isSubmitted = false;
  student: any;
  users: any = [];
  editedUser: any;
  form: FormGroup;
  studentModelObj: StudentModel = new StudentModel();
  studentData !: any;

  constructor(private toastr: ToastrService, private api: ApiService) {
    
  }

  ngOnInit(): void {
    this.form = new FormGroup({
      firstname: new FormControl('', Validators.required),
      lastname: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      number: new FormControl('', [
        Validators.required,
        Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
      ]),
      courses: new FormControl('', [Validators.required]),
      gender: new FormControl('male', Validators.required)
    });
    this.getStudentDetails();
  }

  get firstname() {
    return this.form.get('firstname');
  }
  get lastname() {
    return this.form.get('lastname');
  }
  get email() {
    return this.form.get('email')
  }
  get number() {
    return this.form.get('number');
  }
  get courses() {
    return this.form.get('courses');
  }

  postEmployeeDetails() {
    this.isSubmitted = true;
    this.studentModelObj.firstname = this.form.value.firstname;
    this.studentModelObj.lastname = this.form.value.lastname;
    this.studentModelObj.email = this.form.value.email;
    this.studentModelObj.number = this.form.value.number;
    this.studentModelObj.courses = this.form.value.courses;
    this.studentModelObj.gender = this.form.value.gender;


    if (this.form.valid) {
      this.api.postStudent(this.studentModelObj)
        .subscribe(res => {
          console.log(res);
          this.toastr.success("Data has been added Succesfully");
          let ref = document.getElementById('cancel')
          ref?.click();
          this.form.reset({
            gender: 'male',
            courses: ''
          });
          this.getStudentDetails();
          this.isSubmitted = false;
        })
    }
  }


  getStudentDetails() {
    this.api.getStudent()
      .subscribe(res => {
        this.studentData = res;
      })
  }

  deleteData(student: any) {
    this.api.deleteStudent(student.id)
      .subscribe(res => {
        this.toastr.warning("Data is Deleted");
        this.getStudentDetails();
      })
  }

  onEdit(student: any) {
    this.studentModelObj.id = student.id;
    this.form.controls['firstname'].setValue(student.firstname);
    this.form.controls['lastname'].setValue(student.lastname);
    this.form.controls['email'].setValue(student.email);
    this.form.controls['number'].setValue(student.number);
    this.form.controls['courses'].setValue(student.courses);
    this.form.controls['gender'].setValue(student.gender);
  }

  //Update data
  updateDetails() {
    this.studentModelObj.firstname = this.form.value.firstname;
    this.studentModelObj.lastname = this.form.value.lastname;
    this.studentModelObj.email = this.form.value.email;
    this.studentModelObj.number = this.form.value.number;
    this.studentModelObj.courses = this.form.value.courses;
    this.studentModelObj.gender = this.form.value.gender;

    this.api.updateStudent(this.studentModelObj, this.studentModelObj.id)
      .subscribe(res => {
        this.toastr.success('Data updated successfully.');
        this.form.reset({
          gender: 'male',
          courses: ''
        });
        this.getStudentDetails();
      })
  }
}
