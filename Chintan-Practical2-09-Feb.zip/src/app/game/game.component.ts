import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {
  constructor() { }
  board = [""]
  turn = "X";

  winningPosition = [
    [0, 1, 2, 3],
    [4, 5, 6, 7],
    [8, 9, 10, 11],
    [12, 13, 14, 15],
    [0, 5, 10, 15],
    [3, 6, 9, 12],
    [0, 4, 8, 12],
    [1, 5, 9, 13],
    [2, 6, 10, 14],
    [3, 7, 11, 15]
  ]

  ngOnInit(): void {
    this.board = new Array(16).fill('')
  }

  makeMove(index: number) {
    this.board[index] = this.turn
    this.turn = (this.turn == 'X') ? '0' : 'X';


    for (let i = 0; i < this.winningPosition.length; i++) {
      let winningPosition = this.winningPosition[i]
      let w1 = winningPosition[0];
      let w2 = winningPosition[1];
      let w3 = winningPosition[2];
      let w4 = winningPosition[3];
      if (this.board[w1] != '' && this.board[w1] == this.board[w2] && this.board[w2] == this.board[w3] && this.board[w1] == this.board[w4] && this.board[w2] == this.board[w4]) {
        alert("Player " + this.board[w1] + " has won the game");
        this.board = new Array(16).fill('')
      }
      else{
        let count = 0;
        this.board.forEach((e)=>{
          count += e.length;
        })
        console.log(count);
        if(count == this.board.length){
          alert("Draw");
          this.board = new Array(16).fill('')
        }
      }
    }
  }
}