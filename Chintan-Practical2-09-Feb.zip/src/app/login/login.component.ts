import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) {

  }
  isSubmitted = false;
  ngOnInit(): void {
  }

  form = new FormGroup({
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl('', [
      Validators.required
    ]),
  });

  get email() {
    return this.form.get('email')
  }
  get password() {
    return this.form.get('password')
  }

  register() {
    this.isSubmitted = true;
    // if(this.form.valid) {
    //   if(this.form.value['email'] === 'chintan@123' && this.form.value['password'] === '12345'){
    //     alert("Success");
    //   }
    //   else{

    //     this.isSubmitted = false;
    //   }
    //   this.form.reset();
    // }
    if (this.form.value['email'] === 'chintan@123' && this.form.value['password'] === '12345') {
      console.log("Success");
    }
    else {

      return;
    }
    this.router.navigate(['/game']);
    this.form.reset();
  }

}
