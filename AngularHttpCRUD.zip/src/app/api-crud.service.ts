import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiCrudService {
  apiUrl="http://jsonplaceholder.typicode.com/posts"
  constructor(private _http:HttpClient) { }

  getAllDetail(){
    return this._http.get(this.apiUrl);
  }
}
