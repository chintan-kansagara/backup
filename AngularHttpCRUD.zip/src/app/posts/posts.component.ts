import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ApiCrudService } from '../api-crud.service';
@Component({
  selector: 'posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  details:any[]=[];
  isSubmitted = false;
  student: any;
  users: any = [];
  editedUser: any;
  posts: any;
  private url = 'http://jsonplaceholder.typicode.com/posts';


  constructor(private toastr: ToastrService,private http:HttpClient,private _api:ApiCrudService) {
    // http.get(this.url)
    // .subscribe(response => {
    //   this.posts = response;
    // });
   }

  ngOnInit(): void {
    let ob = this._api.getAllDetail();
    ob.subscribe((res:any)=>{
      this.details = res;
      console.log(this.details);
    });
  }

  form = new FormGroup({
    id: new FormControl('', Validators.required),
    title: new FormControl('', Validators.required),
    content: new FormControl('', Validators.required)
    // email: new FormControl('', [
    //   Validators.required,
    //   Validators.email
    // ]),
    // number: new FormControl('', [
    //   Validators.required,
    //   Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
    // ]),
    // courses: new FormControl('', [Validators.required]),
    // gender: new FormControl('male',Validators.required)
  });


  get id() {
    return this.form.get('id');
  }
  get title() {
    return this.form.get('title');
  }
  get content() {
    return this.form.get('content');
  }







  // get email() {
  //   return this.form.get('email')
  // }
  // get number() {
  //   return this.form.get('number');
  // }
  // get courses() {
  //   return this.form.get('courses');
  // }

  // createPost(input: HTMLInputElement) {
  //   this.isSubmitted = true;
  //   if (this.form.valid) {
  //     let post:any = {title: input.value,content:input.value};
  //     input.value = '';
  //    this.http.post(this.url,JSON.stringify(post))
  //    .subscribe(response => {
  //     post.id = response;
  //     this.posts.splice(0,0,post)
  //     console.log(response);
  //   })
  //     this.toastr.success("Data has been added Succesfully");
  //     this.form.reset();
  //     this.isSubmitted = false;
  //   }
  //   }

  //   updatePost(post:any){
  //     this.http.patch(this.url+'/'+post.id, JSON.stringify({isRead:true}))
  //     .subscribe(response => {
  //       console.log(response)
  //     })
  //   }

  //   deletePost(post:any){
  //     this.http.delete(this.url + '/'+post.id)
  //     .subscribe(response=>{
  //       let index = this.posts.indexOf(post);
  //       this.posts.splice(index,1);
  //     })
  //   }

  // delete(index: number) {
  //   if (confirm("Are you sure you want to Delete")) {
  //     this.users.splice(index, 1);
  //     this.toastr.warning("Data has been Deleted");
  //   }
  // }

  // edit(user: any) {
  //   this.editedUser = user;
  //   this.form.setValue({
  //     id: user.id,
  //     title: user.title,
  //     content: user.content
  //     // email: user.email,
  //     // number: user.number,
  //     // courses: user.courses,
  //     // gender: user.gender
  //   })
  //   //this.form.reset();
  // }

  // save() {
  //   if (this.editedUser) {
  //     this.users.map((val: any, key: number) => {
  //       if (this.editedUser.firstname === val.firstname) {
  //         this.users[key] = this.form.value;
  //       }
  //     })
  //     this.toastr.success("Data has been Edited");
  //     this.form.reset({
  //       // gender: 'male',
  //       // courses: ''
  //     });
  //     this.editedUser = null;
  //   }
  // }
}



