import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService {
  token=localStorage.getItem("token");

  constructor() { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let tokenReq = req.clone({
      setHeaders:{
        Authorization:'Bearer ' + this.token
      }
    })
    return next.handle(tokenReq).pipe(
      catchError((error: HttpErrorResponse) => {
        let errormsg = '';
        
          errormsg = `Server Error: ${error.error.message}`
        
        return throwError(errormsg);
      })
    )
  };
}
