import { UsersService } from './../login/users.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  isSubmitted = false;
  form!: FormGroup;
  constructor(private router: Router, private http: HttpClient, private user: UsersService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      password: new FormControl('', Validators.required),
      confirmpassword: new FormControl('', Validators.required),
      newpassword: new FormControl('', Validators.required)
    });
  }

  get password() {
    return this.form.get('password');
  }
  get confirmpassword() {
    return this.form.get('confirmpassword');
  }
  get newpassword() {
    return this.form.get('newpassword');
  }

  logout(){
    localStorage.removeItem('token')
    this.router.navigate(['/login'])
    this.toastr.warning("");
  }

  postPassword() {
    this.isSubmitted = true;
    if (this.form.valid) {
      let formData: any = new FormData();
      formData.append('password', this.form.get('password').value);
      formData.append('password_confirmation', this.form.get('confirmpassword').value);
      formData.append('newpassword', this.form.get('newpassword').value);

      this.user.changePassword(formData).subscribe({
        next: (res) => console.log(res),
        error: (err) => console.warn(err)

      }
      )
      localStorage.removeItem('token')
       this.toastr.success("Password changed Successfully")
       this.router.navigate(['/login'])
    }
  }

  cancel(){
    this.router.navigate(['/dashboard']);
  }


}

