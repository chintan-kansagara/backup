import { AuthguardGuard } from './shared/authguard.guard';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChangePasswordComponent } from './change-password/change-password.component';


const routes: Routes = [
  {path:'', redirectTo:'login', pathMatch:'full'},
  {path:'register', component: RegistrationComponent},
  {path:'login', component: LoginComponent},
  { path: 'dashboard', loadChildren: () => import('./dash/dash.module').then(m => m.DashModule), canActivate:[AuthguardGuard] },
  {path:'changepassword', component: ChangePasswordComponent, canActivate:[AuthguardGuard]},
  { path: 'cust', loadChildren: () => import('./cust/cust.module').then(m => m.CustModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
