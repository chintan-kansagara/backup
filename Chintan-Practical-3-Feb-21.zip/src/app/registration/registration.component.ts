import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
import { UsersService } from '../login/users.service';

@Component({
  selector: 'registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  isSubmitted = false;
  form!: FormGroup;

  constructor(private toastr: ToastrService, private router: Router, private http: HttpClient,private usersService: UsersService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      firstname: new FormControl('', Validators.required),
      lastname: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.email
      ]),
      number: new FormControl('', [
        Validators.required,
        Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")
      ]),
      password: new FormControl('', Validators.required),
      subscriptiontype: new FormControl('', Validators.required)
    });
  }

  get firstname() {
    return this.form.get('firstname');
  }
  get lastname() {
    return this.form.get('lastname');
  }
  get email() {
    return this.form.get('email')
  }
  get number() {
    return this.form.get('number');
  }
  get password() {
    return this.form.get('password');
  }
  get subscriptiontype() {
    return this.form.get('subscriptiontype');
  }



  postRegisteration() {
    this.isSubmitted = true;

    if (this.form.valid) {

      let formData = new FormData();
      formData.append('first_name', this.form.get('firstname').value);
      formData.append('last_name', this.form.get('lastname').value);
      formData.append('email', this.form.get('email').value);
      formData.append('phone_number', this.form.get('number').value);
      formData.append('password', this.form.get('password').value);
      formData.append('subscription_type', this.form.get('subscriptiontype').value);
  
       
        this.usersService.registerUser(formData).subscribe((res: any) => {
          this.toastr.success("Successfully Registered");
          this.router.navigate(['/login']);
        }, error => {
          console.log(error)
          this.toastr.error(error);
          this.router.navigate(['/register']);
        })
    }
  }
}
