import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http: HttpClient, private router: Router) { }

  login(data: any) {
    return this.http.post("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/login", data)
  }

  changePassword(data: any) {
    // let token = localStorage.getItem('token')
    // var headers = new HttpHeaders().set('Authorization', `bearer ${token}`);
    return this.http.post("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/change-password", data);
  }

  IsloggedIn() {
    return localStorage.getItem('token');
  }

  registerUser(data:any){
    return this.http.post<any>('https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/register',data)
  }

  getDetail(){
    // let token = localStorage.getItem('token')
    // var headers = new HttpHeaders().set('Authorization', `bearer ${token}`);
    return this.http.get<any>("https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/userList")
    .pipe(map((res:any)=>{
      return res;
    }))
  }
}
