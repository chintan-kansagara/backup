import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UsersService } from './users.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private usersService: UsersService,private toastr: ToastrService) { }
  isSubmitted = false;
  ngOnInit(): void {
  }

  form = new FormGroup({
    email: new FormControl('', [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl('', [
      Validators.required
    ]),
  });

  get email() {
    return this.form.get('email')
  }
  get password() {
    return this.form.get('password')
  }
  issubmitted = false;
 
  userLogin(data: any) {
    console.warn(data);
    this.usersService.login(data).subscribe((result:any)=>{
      console.log("result",result.data)
      localStorage.setItem("token",result.data.access_token);
      localStorage.setItem("firstname",result.data.data.first_name);
      localStorage.setItem("lastname",result.data.data.last_name);
      this.toastr.success("Logged in Successfully");
      this.router.navigate(['/dashboard']);
      return !!localStorage.getItem('token');
    }, err => { 
      this.toastr.error(err);
      this.router.navigate(['/login']);
   })
  }

}
