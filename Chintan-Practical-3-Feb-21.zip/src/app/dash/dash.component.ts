import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from '../login/users.service';
import { ToastrService } from 'ngx-toastr';
import { ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-dash',
  templateUrl: './dash.component.html',
  styleUrls: ['./dash.component.css']
})
export class DashComponent implements OnInit {

  data !: any;
  firstname:any;
  lastname:any;
  displayedColumns: string[] = ['first_name', 'last_name', 'email', 'phone_number'];
  dataSource = new MatTableDataSource([]);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private router: Router,private api: UsersService,private toastr: ToastrService) { }
  

  ngOnInit(): void {
    
    this.firstname = localStorage.getItem('firstname')
    this.lastname = localStorage.getItem('lastname')
    this.getData();
    //this.dataSource.paginator = this.paginator;
    console.log(this.firstname)
  }

  passwordPage(){
    this.router.navigate(['/changepassword'])
  }

  logout(){
    localStorage.removeItem('token')
    this.router.navigate(['/login'])
    this.toastr.warning("");
  }

  getData() {
    this.api.getDetail()
      .subscribe(res => {
        debugger;
        this.data = res.data;
        this.dataSource.data = this.data;
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        console.log(res.data);
      })
  }
}
