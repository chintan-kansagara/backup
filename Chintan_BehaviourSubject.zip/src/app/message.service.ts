import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MessageService {
  private subject = new BehaviorSubject<String>('pIZZA!!');
  constructor() { }
  
  sendMessage(message:String){
    this.subject.next(message)
  }

  recievedMessage():Observable<String>{
    return this.subject.asObservable();
  }
}
